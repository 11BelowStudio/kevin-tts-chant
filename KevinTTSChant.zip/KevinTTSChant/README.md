Click on 'kevin tts chant.jar' to run the kevin chanter!

DO NOT DELETE ANY OF THE OTHER JAR FILES, DELETING THEM WILL PROBABLY BREAK EVERYTHING!

Everything apart from kevin tts chant.jar was provided by the fine people who made FreeTTS
https://freetts.sourceforge.io/

kevin tts chant.jar was by github.com/11belowstudio

